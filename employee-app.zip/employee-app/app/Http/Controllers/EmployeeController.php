<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $employees = Employee::orderBy('id','asc')->paginate(2);
        return view('index',compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|unique:employees,email|email',
            'phone' => 'required|numeric|unique:employees,phone',
            'joining_date' => 'required',
            'salary' => 'required'
        ],[
            'phone.unique'=>'phone number already exists'
        ]
    
    );
        $data = $request->except('_token');
        Employee::create($data);
        //    $employee = new Employee;
        //    $employee->name =$data['name'];
        //    $employee->email =$data['email']; 
        //    $employee->phone =$data['phone']; 
        //    $employee->joining_date =$data['joining_date']; 
        //    $employee->salary =$data['salary']; 
        //    $employee->is_active =$data['is_active'];
        //    $employee->save();
        return redirect()->route('employee.index')->withMessage('employee created');
    }

    /**
     * Display the specified resource.
     */
    public function show(Employee $employee)
    {
        return view('show',compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Employee $employee)
    {
        // $employee = Employee::find($id);
        return view('edit',compact('employee'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Employee $employee)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|unique:employees,email,'.$employee->id.'|email',
            'phone' => 'required|numeric|unique:employees,phone,'.$employee->id,
            'joining_date' => 'required',
            'salary' => 'required'
        ],[
            'phone.unique'=>'phone number already exists'
        ]
    
    );
        $data = $request->all();
        // $employee = Employee::find($id);
        $employee->update($data);
return redirect()->route('employee.edit',$employee->id)
->withSuccess('Edit successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Employee $employee)
    {
        $employee->delete();
        return redirect()->route('employee.index',$employee->id)
->withMessage('Delete successfully');
    }
}
